package p3;

public class StudentModel {

}
